<?php
include "../student/connection.php";
$id=$_GET["id"];
$query="UPDATE student_registration SET status='no' WHERE id='$id'";
$result=mysqli_query($conn,$query);
if($result)
{
?>
<script type="text/javascript">
window.location="display_student_info.php";
</script>
<?php
}
?>