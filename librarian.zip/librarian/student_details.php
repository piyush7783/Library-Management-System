<?php 
include "libheader.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
include "../student/connection.php";
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
               <!-- <div class="page-title">
                    <div class="title_left">
                        <h3>Student Details</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Student Details</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
							<table class="table table-bordered">
                                <?php  
								   $b=$_GET["book_name"];
								   $query="select * from issue_books where books_name='$b' && books_return_date=''";
								   $result=mysqli_query($conn,$query);
								   $count=mysqli_num_rows($result);
								   if($count==0)
								   {
									 echo "<tr><td colspan='6'><center><div class='alert alert-danger'><center><h4>This Book is Not Issued To Any Student Now</h4></center></div></center></td></tr>";  
								   }
								   else
								   {
								?>
								<tr>
							       <th>Student Name</th>
								   <th>Student Enrollment</th>
								   <th>Book Name</th>
								   <th>Student Email</th>
								   <th>Student Contact</th>
								   <th>Book Issue Date</th>
								</tr>
								<?php
								   while($var1=mysqli_fetch_assoc($result))
								   {
									   $name=$var1["student_name"];
									   $enroll=$var1["student_enrollment"];
									   $bname=$var1["books_name"];
									   $email=$var1["student_email"];
									   $contact=$var1["student_contact"];
									   $issue=$var1["books_issue_date"];
								?>
								       <tr>
									   <td><?php echo $name; ?></td>
									   <td><?php echo $enroll; ?></td>
									   <td><?php echo $bname; ?></td>
									   <td><?php echo $email; ?></td>
									   <td><?php echo $contact; ?></td>
									   <td><?php echo $issue; ?></td>
									   </tr>
								<?php
								   }}
								?>
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>