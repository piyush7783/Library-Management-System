<html>
<head>
<title> Return Books </title>
</head>
<body>
<?php 
include "libheader.php";
include "../student/connection.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>
        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Return Book</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->
                  
                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Return Book</h2>

                                <div class="clearfix"></div>
                            </div>
								
                            <div class="x_content">
                                <form method="post" action="">
								<table class="table table-bordered">
								   <tr>
								   <td>
								   <select class="form-control" name="sel">
								   <?php
										  $query="select student_enrollment from issue_books where books_return_date=''";
										  $res=mysqli_query($conn,$query);
										  while($var=mysqli_fetch_assoc($res))
										  {
											  $enroll=$var["student_enrollment"];
										?>
								   <option><?php echo $enroll; ?></option>
								   <?php	  
										 }
									?>
								   </select>
								   </td>
								   <td>
								   <input type="submit" class="btn btn-primary" name="submit" value="Search">
								   </td>
								   </tr>
								</table>
								</form>
								<table class="table table-bordered">
								
								<?php
								if(isset($_POST["submit"]))
								{
									$time=date("d-m-y");
									$query1="select * from issue_books where student_enrollment='$_POST[sel]' && books_return_date=''";
									$result2=mysqli_query($conn,$query1);
									?>
									<tr>
										<th>Student Enrollment</th>
										<th>Student Name</th>
										<th>Student Semester</th>
										<th>Student Contact</th>
										<th>Student Email</th>
										<th>Book Name</th>
										<th>Book Issue Date</th>
										<th>Return Book</th>
										</tr>
									<?php
									while($var1=mysqli_fetch_assoc($result2))
									{
										$enr=$var1["student_enrollment"];
										$name=$var1["student_name"];
										$sem=$var1["student_sem"];
										$con=$var1["student_contact"];
										$email=$var1["student_email"];
										$bname=$var1["books_name"];
										$idate=$var1["books_issue_date"];
										?>
										<tr> 
										<td><?php echo $enr; ?></td>
										<td><?php echo $name; ?></td>
										<td><?php echo $sem; ?></td>
										<td><?php echo $con; ?></td>
										<td><?php echo $email; ?></td>
										<td><?php echo $bname; ?></td>
										<td><?php echo $idate; ?></td>
										<td><a href="return.php?id=<?php echo $var1['id']; ?>">Return Book</a></td>
										</tr>
									<?php
									}
								}
								?>
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>
</body>
</html>