<?php 
include "libheader.php";
include "../student/connection.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>
       <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Send message to the student</h2>

                                <div class="clearfix"></div>
                            </div>
							<?php
                                    if(isset($_POST["submit"]))
                                    {
                                        $user=$_POST["sel"];
                                        $title=$_POST["title"];
                                        $msg=$_POST["msg"];
										$status="n";
                                        if(empty($user)||empty($title)||empty($msg))
                                        {
                                            echo "<div style='color:red; font-size:20px;'>*Please fill all the fields</div>";
                                        }
                                        else
                                        {
                                            $query1="insert into messages values('','$_SESSION[librarian]','$user','$title','$msg','$status')";
                                            $result1=mysqli_query($conn,$query1);
                                            if($result1)
                                            {
                                            ?>
                                                <script type="text/javascript">
                                                    alert("Message sent Successfully");
                                                </script>
                                            <?php
                                        }
                                        else
                                        {
                                            die("Query FAILED" . mysqli_error($conn));
                                        }
                                        }
                                    }
                                ?>
                            <div class="x_content">
                                <?php
                                    $result=mysqli_query($conn,"select * from student_registration");
                                ?>
                                <div class="col-lg-6">
                                <table class="table table-hover">
                                    <form method="post" action="">
                                        <tr>
                                            <td>
                                                <select name="sel" class="form-control">
                                                    <?php
                                                        while($var=mysqli_fetch_assoc($result))
                                                        {
                                                            ?>
                                                                <option value="<?php echo $var['username']; ?>"><?php echo $var["username"]."(".$var["enrollment"].")" ?></option>
                                                            <?php
                                                        }
                                                    ?>                                                    
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input type="text" name="title" class="form-control" placeholder="Enter Title">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <textarea name="msg" class="form-control" placeholder="Message"></textarea>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <center><input type="submit" name="submit" class="btn btn-primary" value="Send"></center>
                                            </td>
                                        </tr>
                                    </form>
                                </table>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>