<?php
include "../student/connection.php";
$id=$_GET["id"];
$time=date("d-m-y");
$query="update issue_books set books_return_date='$time' where id='$id'";
$query1="select * from issue_books where id='$id'";
$results=mysqli_query($conn,$query);
$var=mysqli_query($conn,$query1);
while($var1=mysqli_fetch_assoc($var))
{
	$name=$var1["books_name"];
}
$query2="update add_books set available_quantity=available_quantity+1 where book_name='$name'";
$var=mysqli_query($conn,$query2);
if($results)
{
	?>
	<script type="text/javascript">
	alert("Book Has Returned Successfully");
	window.location="return_books.php";
	</script>
	<?php
}
?>