<?php
include "libheader.php";
include "../student/connection.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>
<html>
<head>
<title> Issue Books </title>
</head>
<body>
<?php 
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Issue Books</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Issue Books</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form action="" method="post">
								<table class="table table-bordered">
								<tr>
								<td>
								<select name="sel" class="form-control selectpicker">
								<?php
								$query="select enrollment from student_registration";
								$result=mysqli_query($conn,$query);
								while($var=mysqli_fetch_assoc($result))
								{
									$enrollment=$var["enrollment"];
									?>
									<option><?php echo $enrollment; ?></option>
							<?php		
								}
								?>
								</select>
								</td>
								<td>
								<input type="submit" name="submit" value="search" class="btn btn-primary">
								</td>
								</tr>
								</table>
								<table class="table table-bordered">
								<?php
								if(isset($_POST["submit"]))
								{
									$sel=$_POST["sel"];
									$query="select * from student_registration where enrollment='$sel'";
									$result=mysqli_query($conn,$query);
									$row=mysqli_fetch_assoc($result);
									$name=$row["first_name"]." ".$row["last_name"];
									$_SESSION["name"]=$name;
									$sem=$row["sem"];
									$_SESSION["sem"]=$sem;
									$contact=$row["contact"];
									$_SESSION["contact"]=$contact;
									$email=$row["email"];
									$_SESSION["email"]=$email;
									$username=$row["username"];
									$_SESSION["username"]=$username;
									$enrollment=$row["enrollment"];
									$_SESSION["enrollment"]=$enrollment;
									
								?>
								<tr>
								   <td>
								   <input type="text" name="enrollment" class="form-control" value="<?php echo $enrollment; ?>" placeholder="Enrollment NO" disabled>
								   </td>
								</tr>
								  <tr>
								   <td>
								   <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" placeholder="Student Name" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="sem" class="form-control" value="<?php echo $sem; ?>" placeholder="Student Semester" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="contact" class="form-control" value="<?php echo $contact; ?>" placeholder="Student Contact" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" placeholder="Student Email" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <select name="sub" class="form-control selectpicker">
								   <?php
								   $query="select book_name from add_books";
								   $results=mysqli_query($conn,$query);
								   while($var=mysqli_fetch_assoc($results))
								   {
									   $book=$var["book_name"];
								?>
									 <option><?php echo $book; ?></option>  
							   <?php
								   }
								   ?>
								   </select>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="book_issue" class="form-control" value="<?php echo date("d-m-y"); ?>" placeholder="Book Issue Date" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="username" class="form-control" value="<?php echo $username; ?>" placeholder="Student Username" disabled>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <center><input type="submit" name="submit2" class="btn btn-primary" value="Issue Book"></center>
								   </td>
								   </tr>
								<?php
								}
								?>
								</table>
								</form>
								<?php
								if(isset($_POST["submit2"]))
								{
									$sub=$_POST["sub"];
									$query2="select * from add_books where book_name='$sub'";
									$result3=mysqli_query($conn,$query2);
									while($var2=mysqli_fetch_assoc($result3))
									{
										$avail_qty=$var2["available_quantity"];
									}
										if($avail_qty==0)
										{
											echo '<center><div style="font-size:15px;" class="alert alert-danger"><center>This book is not available in stock</center></div></center>';
										}
										else
										{
											$issue=date("d-m-y");
									        $query1="insert into issue_books (id,student_enrollment,student_name,student_sem,student_contact,student_email,books_name,books_issue_date,student_username) value('','$_SESSION[enrollment]','$_SESSION[name]','$_SESSION[sem]','$_SESSION[contact]','$_SESSION[email]','$sub','$issue','$_SESSION[username]')";
									        $query2="update add_books set available_quantity=available_quantity-1 where book_name='$sub'";
									        $result1=mysqli_query($conn,$query1);
									        mysqli_query($conn,$query2);
									        if($result1)
									        {
								?>
												<script type="text/javascript">
												  alert("Book is successfully issued");
												  window.location.href=window.location.href;
												</script>
								<?php
									}
										}
								}
								?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>
</body>
</html>