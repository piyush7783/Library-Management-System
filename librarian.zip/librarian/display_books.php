<?php 
include "libheader.php";
include "../student/connection.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Display Books</h3>
                    </div>
                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" name="searchcon" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" name="submit" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Display Books</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
							<div class="col-lg-5">
							<form method="post" action="">
							<input type="text" placeholder="search here.." class="form-control" name="searchcon"></br>
							<input type="submit" class="btn btn-primary" value="search" name="submit">
							</form></div>
							<div><table class="table table-bordered">
                                <tr>
								<th>Name</th>
								<th>Image</th>
								<th>Author</th>
								<th>Publication</th>
								<th>Purchase Date</th>
								<th>Price</th>
								<th>Books Quantity</th>
								<th>Available Quantity</th>
								<th>Delete Books</th>
								</tr>
								<?php
								if(isset($_POST["submit"]))
								{
								$search=$_POST["searchcon"];
								if(empty($search))
								{
									echo "<div style='color:red; font-size:18px; font-weight:bold;'>*please enter something to search</div>";
								}
								else{
								$query="SELECT * FROM add_books WHERE book_name LIKE('%$search%')";
								$results=mysqli_query($conn,$query);
								$count=mysqli_num_rows($results);
								if($count==0)
								{
									echo "<div style='color:red; font-size:18px; font-weight:bold;'>*no any content found</div>";
								}
								else{
								while($var=mysqli_fetch_assoc($results))
								{
									$name=$var["book_name"];
									$image=$var["book_image"];
									$author=$var["book_author"];
									$publication=$var["book_publication"];
									$pur=$var["book_purchase_date"];
									$price=$var["book_price"];
									$bqty=$var["book_quantity"];
									$aqty=$var["available_quantity"];
									?>
									<tr>
									<td><?php echo $name;?></td>
									<td><?php echo "<img src='{$image}' height='100' width='100'>";?></td>
									<td><?php echo $author;?></td>
									<td><?php echo $publication;?></td>
									<td><?php echo $pur;?></td>
									<td><?php echo $price;?></td>
									<td><?php echo $bqty;?></td>
									<td><?php echo $aqty;?></td>
									<td><a class="btn btn-danger" href="delete_book.php?id=<?php echo $var['id']; ?>">Delete</a></td>
									</tr>
								<?php
								}
								?>
								<?php
								}
								?>
								<?php
								}
								?>
								<?php
								}
								else
								{
								$query="SELECT * FROM add_books";
								$results=mysqli_query($conn,$query);
								while($var=mysqli_fetch_assoc($results))
								{
									$name=$var["book_name"];
									$image=$var["book_image"];
									$author=$var["book_author"];
									$publication=$var["book_publication"];
									$pur=$var["book_purchase_date"];
									$price=$var["book_price"];
									$bqty=$var["book_quantity"];
									$aqty=$var["available_quantity"];
									?>
									<tr>
									<td><?php echo $name;?></td>
									<td><?php echo "<img src='{$image}' height='100' width='100'>";?></td>
									<td><?php echo $author;?></td>
									<td><?php echo $publication;?></td>
									<td><?php echo $pur;?></td>
									<td><?php echo $price;?></td>
									<td><?php echo $bqty;?></td>
									<td><?php echo $aqty;?></td>
									<td><a class="btn btn-danger" href="delete_book.php?id=<?php echo $var['id']; ?>">Delete</a></td>
									</tr>
								<?php
								}
								?>
								<?php
								}
								?>
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>