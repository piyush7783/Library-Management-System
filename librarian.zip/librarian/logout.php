<?php
session_start();
unset($_SESSION["librarian"]);
?>
<script>
window.location="liblogin.php";
</script>