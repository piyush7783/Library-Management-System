<?php
include "../student/connection.php";
if(isset($_GET["id"]))
{
$id=$_GET[id];
$result=mysqli_query($conn,"delete from add_books where id='$id'");
?>
<script>
window.location="display_books.php";
</script>
<?php } 
else
{
	?>
<script>
window.location="display_books.php";
</script>
<?php
}
?>