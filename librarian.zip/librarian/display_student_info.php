<?php 
include "libheader.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Student Details</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <?php
								include "../student/connection.php";
								$query="SELECT * FROM student_registration";
								$result=mysqli_query($conn,$query);
								?>
								<table class="table table-bordered table-hover">
								<tr>
								<th>Firstname</th>
								<th>Lastname</th>
								<th>Username</th>
								<th>Email</th>
								<th>Contact</th>
								<th>Semester</th>
								<th>Enrollment</th>
								<th>Status</th>
								<th>Approve</th>
								<th>Not Approve</th>
								</tr>
								<?php
								while($student=mysqli_fetch_assoc($result))
								{
									$firstname=$student['first_name'];
									$lastname=$student['last_name'];
									$username=$student['username'];
									$email=$student['email'];
									$contact=$student['contact'];
									$sem=$student['sem'];
									$enrollment=$student['enrollment'];
									$status=$student['status'];
								?>
								<tr>
								<td><?php echo $firstname; ?></td>
								<td><?php echo $lastname; ?></td>
								<td><?php echo $username; ?></td>
								<td><?php echo $email; ?></td>
								<td><?php echo $contact; ?></td>
								<td><?php echo $sem; ?></td>
								<td><?php echo $enrollment; ?></td>
								<td><?php echo $status; ?></td>
								<td><a href="approve.php?id=<?php echo $student['id']; ?>">Approve</a></td>
								<td><a href="notapprove.php?id=<?php echo $student['id']; ?>">Not Approve</a></td>
								</tr>
								
								<?php
								}
								?>
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "libfooter.php";
}
?>