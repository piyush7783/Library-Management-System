<?php 
include "libheader.php";
include "../student/connection.php";
if(!isset($_SESSION["librarian"]))
{
	?>
	<script>
        window.location="liblogin.php";
    </script>
	<?php
}
else
{
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Add Books Info</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_content">
                                <form class="col-lg-6" action="" method="post" enctype="multipart/form-data">
								   <table class="table table-bordered">
								   <tr>
								   <td>
								   <input type="text" name="books_name" class="form-control" placeholder="Books Name" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   Books Image
								   <input type="file" name="f1" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="books_author" class="form-control" placeholder="Books Author Name" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="pname" class="form-control" placeholder="Books Publication" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="books_purchase_date" class="form-control" placeholder="Books Purchase Date" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="books_price" class="form-control" placeholder="Books Price" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="books_qty" class="form-control" placeholder="Books Quantity" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="text" name="avail_qty" class="form-control" placeholder="Books Available Quantity" required=""/>
								   </td>
								   </tr>
								   <tr>
								   <td>
								   <input type="submit" name="submit" class="btn btn-primary submit" value="Add Books Details"/>
								   </td>
								   </tr>
								   </table>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
		if(isset($_POST["submit"]))
		{
			$tm=md5(time());
			$fnm=$_FILES["f1"]["name"];
			$dst="./books_image/".$tm.$fnm;
			$dst1="books_image/".$tm.$fnm;
			move_uploaded_file($_FILES["f1"]["tmp_name"],$dst);
			$name=$_POST["books_name"];
			$author=$_POST["books_author"];
			$pname=$_POST["pname"];
			$books_purchase_date=$_POST["books_purchase_date"];
			$books_price=$_POST["books_price"];
			$books_qty=$_POST["books_qty"];
			$avail_qty=$_POST["avail_qty"];
			if($name!="" && $author!="" && $pname!="" && $books_purchase_date!="" && $books_price!="" && $books_qty!="" && $avail_qty!="")
			{
			$query="insert into add_books (book_name,book_image,book_author,book_publication,book_purchase_date,book_price,book_quantity,available_quantity,librarian_username)
			VALUES('$name','$dst1','$author','$pname','$books_purchase_date','$books_price','$books_qty','$avail_qty','$_SESSION[librarian]')";
			$result=mysqli_query($conn,$query);
			if($result)
			{
				?>
				<script type="text/javascript">
				  alert("Book Details Inserted Successfully");
				</script>
			<?php
			}
			else
			{
				echo "Not Inserted";
			}
		}
		}
		?>
<?php
include "libfooter.php";
}
?>