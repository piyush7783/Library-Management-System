<?php
include "header.php";
include "connection.php";
if(!isset($_SESSION["user"]))
{
	?>
	<script>
        window.location="index.php";
    </script>
	<?php
}
else
{ 
$results=mysqli_query($conn,"update messages set read1='y' where dusername='$_SESSION[user]'");
?>
       <div class="right_col" role="main">
            <div class="">

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Librarian message</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <?php
                                    $result=mysqli_query($conn,"select * from student_registration");
                                ?>
                                <div class="col-lg-12">
                                <table class="table table-bordered">
                                    <form method="post" action="">
									<tr>
									<th>Librarian Name</th>
									<th>Title</th>
									<th>Message</th>
									</tr>
									<?php
									$result=mysqli_query($conn,"select * from messages where dusername='$_SESSION[user]' order by id DESC");
									while($var=mysqli_fetch_assoc($result))
									{
										$result1=mysqli_query($conn,"select * from liberarian where username='$var[susername]'");
										while($var1=mysqli_fetch_assoc($result1))
										$fullname=$var1['firstname']." ".$var1['lastname'];
									    $title=$var["title"];
										$message=$var["msg"];
									?>
										<tr>
                                            <td>
                                               <?php echo $fullname;  ?> 
                                            </td>
                                            <td>
                                                <?php echo $title;  ?>
                                            </td>
                                            <td>
                                                <?php echo $message;  ?>
                                            </td>
                                        </tr>
								<?php
									}
								?>
                                    </form>
                                </table>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "footer.php";
}
?>