<?php
session_start();
unset($_SESSION["user"]);
?>
<script>
window.location="index.php";
</script>