<html>
<head>
<title>Search Books</title>
</head>
<body>
<?php 
include "header.php";
include "connection.php";
if(!isset($_SESSION["user"]))
{
	?>
	<script>
        window.location="index.php";
    </script>
	<?php
}
else
{
?>

        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <!--<div class="page-title">
                    <div class="title_left">
                        <h3>Search Books</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>-->
                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Search Books</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <table class="table table-bordered">
								<form method="post" action="">
								<tr>
								<td colspan="2"><input type="text" name="search" class="form-control" placeholder="Search Books"></td>
								<td><input type="submit" class="btn btn-primary" name="submit" value="Search"></td>
								</tr>
								</form>
								<?php
								if(isset($_POST["submit"]))
								{
								$a=$_POST["search"];
								if($a=="")
								{
								?>
									<p style="color:red; font-size:20px;">*Please Write Something To Search Here</p>
								<?php
								}
								else
								{
								$query="select * from add_books where book_name like('%$a%')";
								$results=mysqli_query($conn,$query);
								$count=mysqli_num_rows($results);
					            if($count==0)
					            {
						          echo "<p style='color:red; font-size:20px;'>No Results Found</p>";
					            }
								else{
								echo "<tr>";
								$i=0;
								while($var=mysqli_fetch_assoc($results))
								{
									$i=$i+1;
								echo '<td>';
								?>
								<img src='../librarian/<?php echo $var["book_image"]; ?>' height="100" width="100"><br>
								<b><?php echo $var["book_name"]; ?></b><br>
								<b>Available:<?php echo $var["available_quantity"]; ?></b>
								<?php
								echo '</td>';	
                               if($i==3)
							   {
								   echo '</tr>';
								   echo '<tr>';
								   $i=0;
							   }								   
								}
								echo '</tr>';
								}
								}
								}
								?>
								</table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
<?php
include "footer.php";
}
?>
</body>
</html>